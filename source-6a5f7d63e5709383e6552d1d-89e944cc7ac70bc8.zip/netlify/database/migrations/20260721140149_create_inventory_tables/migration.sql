CREATE TABLE "daily_snapshot_items" (
	"id" serial PRIMARY KEY,
	"snapshot_id" integer NOT NULL,
	"product_id" integer NOT NULL,
	"counted_quantity" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "daily_snapshots" (
	"id" serial PRIMARY KEY,
	"snapshot_date" date NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" serial PRIMARY KEY,
	"sku" text NOT NULL,
	"name" text NOT NULL,
	"unit" text DEFAULT 'unidades' NOT NULL,
	"minimum_stock" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "stock_lots" (
	"id" serial PRIMARY KEY,
	"product_id" integer NOT NULL,
	"source_type" text NOT NULL,
	"source_reference" text NOT NULL,
	"quantity" integer NOT NULL,
	"expiration_date" date NOT NULL,
	"received_date" date NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "snapshot_product_unique" ON "daily_snapshot_items" ("snapshot_id","product_id");--> statement-breakpoint
CREATE INDEX "snapshot_items_product_idx" ON "daily_snapshot_items" ("product_id");--> statement-breakpoint
CREATE UNIQUE INDEX "daily_snapshots_date_unique" ON "daily_snapshots" ("snapshot_date");--> statement-breakpoint
CREATE UNIQUE INDEX "products_sku_unique" ON "products" ("sku");--> statement-breakpoint
CREATE INDEX "stock_lots_product_idx" ON "stock_lots" ("product_id");--> statement-breakpoint
CREATE INDEX "stock_lots_expiration_idx" ON "stock_lots" ("expiration_date");--> statement-breakpoint
CREATE INDEX "stock_lots_received_idx" ON "stock_lots" ("received_date");--> statement-breakpoint
ALTER TABLE "daily_snapshot_items" ADD CONSTRAINT "daily_snapshot_items_snapshot_id_daily_snapshots_id_fkey" FOREIGN KEY ("snapshot_id") REFERENCES "daily_snapshots"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "daily_snapshot_items" ADD CONSTRAINT "daily_snapshot_items_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "stock_lots" ADD CONSTRAINT "stock_lots_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE CASCADE;